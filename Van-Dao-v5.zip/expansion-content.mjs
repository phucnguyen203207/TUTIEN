export default {
  crops:[
    {id:'herb',name:'Thanh Linh Thảo',symbol:'草',cost:8,duration:45,item:'m0',yield:5,description:'Dễ trồng, dùng cho mọi đan phương.'},
    {id:'flower',name:'Thanh Linh Hoa',symbol:'花',cost:20,duration:90,item:'m3',yield:4,description:'Nguyên liệu Hồi Xuân Đan, dưỡng khí hồi nguyên.'},
    {id:'fungus',name:'Tử Linh Chi',symbol:'芝',cost:35,duration:150,item:'m4',yield:4,description:'Linh dược hỗ trợ đột phá, hương thơm thanh khiết.'},
    {id:'lotus',name:'Ngọc Tủy Liên',symbol:'蓮',cost:55,duration:210,item:'m5',yield:3,description:'Dược liệu quý để dưỡng thần, tăng tâm cảnh.'}
  ],
  buildings:[
    {id:'array',name:'Tụ Linh Trận',symbol:'阵',cost:120,max:8,description:'Mỗi cấp tăng 12% tốc độ tu luyện.'},
    {id:'garden',name:'Linh Dược Viên',symbol:'園',cost:90,max:6,description:'Mỗi cấp thêm một ô đất và tăng 10% sản lượng.'},
    {id:'furnace',name:'Thanh Ngọc Đan Lô',symbol:'炉',cost:100,max:5,description:'Mỗi cấp thêm 2% tỉ lệ thành đan, tối đa 99%.'}
  ],
  gear:[
    {id:'g0',name:'Thanh Phong Kiếm',slot:'weapon',symbol:'劍',grade:'Phàm',cost:100,materials:{m1:3,m0:2},realm:0,stat:'attack',bonus:8},
    {id:'g1',name:'Vân Văn Pháp Y',slot:'armor',symbol:'衣',grade:'Phàm',cost:90,materials:{m0:6,m2:2},realm:0,stat:'hp',bonus:45},
    {id:'g2',name:'Bích Ngọc Bội',slot:'charm',symbol:'玉',grade:'Phàm',cost:120,materials:{m3:3,m1:2},realm:0,stat:'xp',bonus:.15},
    {id:'g3',name:'Xích Diễm Kiếm',slot:'weapon',symbol:'劍',grade:'Hoàng',cost:600,materials:{m6:5,m2:6},realm:4,stat:'attack',bonus:90},
    {id:'g4',name:'Huyền Thiết Giáp',slot:'armor',symbol:'甲',grade:'Hoàng',cost:550,materials:{m1:12,m6:3},realm:4,stat:'hp',bonus:450},
    {id:'g5',name:'Ngưng Thần Ngọc',slot:'charm',symbol:'珏',grade:'Hoàng',cost:700,materials:{m5:6,m7:3},realm:4,stat:'xp',bonus:.35}
  ],
  sects:[
    {id:'cloud',name:'Thanh Vân Tông',symbol:'雲',motto:'Tâm như mây trắng, đạo tự thong dong.',bonus:'Tu luyện +15%',xp:.15,attack:0,description:'Ẩn giữa núi xanh, lấy dưỡng tâm và trường sinh làm gốc.'},
    {id:'sword',name:'Vạn Kiếm Sơn',symbol:'劍',motto:'Một kiếm phá vạn pháp.',bonus:'Công kích +18%',xp:0,attack:.18,description:'Kiếm tu hội tụ, lấy chiến đấu tôi luyện đạo tâm.'},
    {id:'lotus',name:'Dược Vương Cốc',symbol:'蓮',motto:'Một đan cứu thế, vạn dược quy tâm.',bonus:'Luyện đan +8% thành công',xp:0,attack:0,description:'Nơi đan đạo hưng thịnh, linh thảo mọc khắp sơn cốc.'}
  ],
  talents:[
    {id:'flow',name:'Linh Khí Quán Thể',symbol:'氣',max:5,description:'Mỗi điểm +10% tốc độ tu luyện.'},
    {id:'blade',name:'Kiếm Tâm Thông Minh',symbol:'劍',max:5,description:'Mỗi điểm +8% công kích.'},
    {id:'vitality',name:'Bất Diệt Đạo Thể',symbol:'體',max:5,description:'Mỗi điểm +12% sinh lực tối đa.'},
    {id:'clarity',name:'Minh Tâm Kiến Tính',symbol:'心',max:5,description:'Mỗi điểm +2% tỉ lệ đột phá.'},
    {id:'fortune',name:'Thiên Mệnh Chiếu Cố',symbol:'運',max:5,description:'Mỗi điểm +2% chí mạng và +5% linh thạch chiến đấu.'},
    {id:'harvest',name:'Vạn Vật Sinh Trưởng',symbol:'生',max:5,description:'Mỗi điểm +15% sản lượng linh điền.'}
  ],
  achievements:[
    {id:'a0',name:'Nhất niệm nhập đạo',description:'Thổ nạp 5 lần.',key:'manual',target:5,stones:80,insight:1},
    {id:'a1',name:'Sơ lộ phong mang',description:'Chiến thắng 3 trận.',key:'wins',target:3,stones:120,insight:1},
    {id:'a2',name:'Đan hương vấn đạo',description:'Luyện thành 3 viên đan.',key:'crafted',target:3,stones:150,insight:1},
    {id:'a3',name:'Dược viên sơ thành',description:'Thu hoạch 3 ô linh điền.',key:'harvests',target:3,stones:120,insight:1},
    {id:'a4',name:'Bách luyện thành khí',description:'Rèn 1 pháp bảo.',key:'forged',target:1,stones:150,insight:1},
    {id:'a5',name:'Phù vân đệ tử',description:'Gia nhập một tông môn.',key:'joined',target:1,stones:80,insight:1},
    {id:'a6',name:'Vấn đạo Trúc Cơ',description:'Đạt Trúc Cơ sơ kỳ.',key:'realm',target:4,stones:500,insight:2},
    {id:'a7',name:'Phá tháp tam tầng',description:'Vượt 3 tầng Vấn Thiên Tháp.',key:'tower',target:3,stones:250,insight:1},
    {id:'a8',name:'Linh thú kết duyên',description:'Linh thú đạt cấp 3.',key:'petLevel',target:3,stones:200,insight:1},
    {id:'a9',name:'Bách chiến vô song',description:'Chiến thắng 30 trận.',key:'wins',target:30,stones:800,insight:2},
    {id:'a10',name:'Kim đan đại đạo',description:'Đạt Kim Đan sơ kỳ.',key:'realm',target:8,stones:1500,insight:3},
    {id:'a11',name:'Vạn dặm tiên duyên',description:'Hoàn thành 10 chuyến lịch luyện.',key:'expeditions',target:10,stones:500,insight:2}
  ],
  encounters:[
    {id:'spring',name:'Linh tuyền trong sương',symbol:'泉',description:'Sau rặng trúc, một dòng suối ánh ngọc xuất hiện. Linh khí dịu dàng dẫn bạn đến bên bờ.',choices:[{label:'Tĩnh tọa bên suối',text:'Tâm như mặt nước. Tâm cảnh +2.',mind:2},{label:'Thu thập linh thảo',text:'Tìm được 8 linh thảo và 3 thanh linh hoa.',items:{m0:8,m3:3}}]},
    {id:'merchant',name:'Du thương giữa núi',symbol:'商',description:'Một lão nhân gánh hàng dưới tán tùng. Ông mời bạn đổi linh thạch lấy một túi khoáng thạch.',choices:[{label:'Đổi 40 linh thạch',cost:40,text:'Nhận 6 huyền thiết và 3 xích đồng.',items:{m1:6,m6:3}},{label:'Hỏi chuyện tiên duyên',text:'Câu chuyện của lão nhân giúp tâm cảnh +1.',mind:1}]},
    {id:'tablet',name:'Cổ bia vô tự',symbol:'碑',description:'Trên vách đá phủ rêu, nét kiếm xưa thoắt ẩn thoắt hiện. Bạn nghe thấy tiếng chuông từ ngàn năm trước.',choices:[{label:'Lĩnh ngộ kiếm ý',text:'Cảm nhận đạo vận. Nhận tu vi bằng 40 giây tu luyện.',seconds:40},{label:'Tìm vật bị chôn giấu',text:'Tìm được 1 Tiên ngọc.',jade:1}]}
  ]
};
