import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import * as F from './dist/formulas.js';
const d=JSON.parse(readFileSync(new URL('./dist/data.json',import.meta.url)));
const s={root:'Mộc',realm:0,rebirth:0,equipped:['t0'],learned:{t0:1},mind:10,breakBonus:0};
assert.equal(d.realms.length,20);assert.equal(d.roots.length,30);assert.equal(d.items.length,177);assert.equal(d.herbs.length,20);assert.equal(d.treasures.length,14);assert.equal(d.recipes.length,26);assert.equal(d.enemies.filter(x=>x.boss).length,5);assert.equal(d.enemies.filter(x=>!x.boss).length,15);assert.equal(d.quests.length,15);
for(let i=1;i<20;i++)assert.equal(d.realms[i].requirement/d.realms[i-1].requirement,2);
assert(F.xpRate(s,d)>1);const base=F.xpRate(s,d);assert(F.xpRate({...s,realm:1},d)>base);assert(F.xpRate({...s,rebirth:1},d)>base*1.29);
assert.equal(F.elapsedSeconds(0,24*3600*1000),8*3600);assert.equal(F.elapsedSeconds(5000,0),0);assert.equal(F.elapsedSeconds(0,1500),1.5);
assert.equal(F.breakthroughChance({...s,mind:1000,breakBonus:10}),.98);assert.equal(F.breakthroughChance(s),.78);assert(F.damage(10,1,'Kim','Mộc')>F.damage(10,1,'Kim','Thủy'));assert.equal(F.damage(1,100,'Kim','Thổ'),1);
assert.equal(F.slots(s),1);assert.equal(F.slots({...s,realm:16}),4);
const itemIds=new Set(d.items.map(i=>i.id));for(const r of d.recipes)for(const id of Object.keys(r.materials))assert(itemIds.has(id));
// A passive first breakthrough takes approximately five minutes for each basic root.
for(const root of d.roots.slice(0,5)){const seconds=360/F.xpRate({...s,root:root.name},d);assert(seconds>=210&&seconds<=300)}
F.configure(d);
const bonusState={...s,estate:{array:1},talents:{flow:1},gear:{g2:1},loadout:{charm:'g2'},sect:{id:'cloud'},pet:{level:1}};
assert(F.xpRate(bonusState,d)>base*1.5);
const from=Date.now()-120000,to=from+120000,focusUntil=from+60000;
const focused={...s,focusUntil};assert(Math.abs(F.cultivationGain(focused,d,from,to)-base*150)<.001);
assert(Math.abs(F.cultivationGain({...s,focusUntil:from-1000},d,from,to)-base*120)<.001);
assert(F.alchemyChance({estate:{furnace:5},sect:{id:'lotus'}},{success:.95})<=.99);
assert(F.cropYield({estate:{garden:2},talents:{harvest:2}},{yield:5})>=7);
for(let floor=2;floor<=30;floor++)assert(F.towerEnemy(floor,d).hp>F.towerEnemy(floor-1,d).hp);
console.log('PASS: content counts, realm growth, cultivation bonuses, elemental combat, offline cap, skill slots and first-breakthrough balance.');
assert.equal(d.origins.length,8);assert.equal(new Set(d.roots.map(r=>r.name)).size,30);
const neutral={...s,root:'Kim',realm:0,rebirth:0,ancestry:{chosen:false},automation:{cultivate:false}};
for(const r of d.roots){const a={...neutral,root:r.name};for(const value of [F.xpRate(a,d),F.maxHp(a),F.maxMana(a),F.attack(a),F.defense(a)])assert(Number.isFinite(value)&&value>0);assert(F.critChance(a)>=.01&&F.critChance(a)<=.75);assert(F.breakthroughChance(a)>=.05&&F.breakthroughChance(a)<=.98);for(const element of r.affinities)assert(F.matchesRoot(a,element))}
assert(F.attack({...neutral,root:'Kim'})>F.attack({...neutral,root:'Mộc'}));
assert(F.breakthroughChance({...neutral,root:'Lôi'})<F.breakthroughChance(neutral));
assert(F.maxHp({...neutral,root:'Thiên Hỏa'})<F.maxHp(neutral));
assert(F.alchemyChance({...neutral,root:'Thiên Hỏa'},{success:.8})>F.alchemyChance(neutral,{success:.8}));
assert.equal(F.medicineToxicity({...neutral,root:'Độc Mộc'},{toxicity:2,multiplier:1}),1);
assert.equal(F.matchesRoot({...neutral,root:'Vô'},'Kim'),false);
for(const e of ['Kim','Mộc','Thủy','Hỏa','Thổ'])assert(F.matchesRoot({...neutral,root:'Ngũ Hành'},e));
assert(F.xpRate({...neutral,root:'Luân Hồi',rebirth:2},d)/F.xpRate({...neutral,root:'Luân Hồi'},d)>1.6);
console.log('PASS: all 30 root builds stay valid, affinity coverage, combat/pill/breakthrough tradeoffs, poison resistance and reincarnation affinity.');
