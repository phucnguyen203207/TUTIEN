# Tranh nhân vật Vân Đạo 4.0

Công cụ: image_gen tích hợp (built-in), không dùng CLI hay API key. Tạo mới một atlas 3 cột × 2 hàng gồm 6 chân dung nguyên bản, không tham chiếu ảnh nhân vật có sẵn. Kiểm tra ảnh rồi mã hóa JPEG chất lượng 88 cho game, giữ ảnh PNG gốc.

- Ảnh nguồn dự án: dist/assets/npc-atlas.png
- Ảnh dùng trong game: dist/assets/npc-atlas.jpg
- File HTML độc lập nhúng JPEG để mở offline.

## Prompt đã dùng

Use case: stylized-concept. Asset type: ONE game NPC portrait atlas, a perfectly regular 3 columns by 2 rows grid, six equal rectangular panels, total landscape 1536x1024. Each panel is a separate beautiful hand-painted xianxia character bust portrait, centered from head to waist, no panel borders, no text anywhere. Original characters for a Vietnamese cultivation game, cohesive refined Chinese ink watercolor meets detailed wuxia character concept art, cream parchment background, sage jade green and muted antique gold palette, delicate flowing fabric, expressive faces, atmospheric mist, elegant premium painted game art. Row 1 left: gentle young female herbalist, jade green hanfu, black hair with bamboo hairpin, holding a small white medicinal flower. Row 1 middle: calm handsome young male swordsman in ivory and deep teal robes, long black ponytail, one sheathed sword diagonally behind shoulder. Row 1 right: smiling elderly male alchemist with long white beard, sage robes, copper miniature incense censer. Row 2 left: spirited adult female talisman master in rust-red and cream robes, auburn-black hair, holding a gold talisman paper. Row 2 middle: enigmatic adult male masked traveling merchant in indigo and gold robes, elegant half-face mask, small jade gourd. Row 2 right: serene adult female formation master, silver-white hair, pale blue robes, floating subtle golden astrolabe. Faces and torso fit comfortably in each equal cell with margins. Consistent framing and scale. No existing fictional characters, no writing, no UI, no logos, no watermarks. Actual richly detailed painted portraits, not symbols or stick figures.

## Nguồn tham khảo mô-típ

- [A Record of a Mortal’s Journey to Immortality / Phàm Nhân Tu Tiên](https://www.wuxiaworld.com/novel/rmji): giới thiệu người phàm gia nhập tông môn và tìm con đường trường sinh. Gợi ý thiết kế hành trình chậm, chế tạo và tích lũy cơ duyên.
- [Renegade Immortal / Tiên Nghịch](https://www.wuxiaworld.com/novel/renegade-immortal/): giới thiệu hành trình vượt tư chất để trở thành người tu tiên. Gợi ý thiết kế mục tiêu vượt cảnh giới và quan hệ nhân vật.
- [A Will Eternal / Nhất Niệm Vĩnh Hằng](https://www.wuxiaworld.com/novel/a-will-eternal/): trang chính thức có nhãn Alchemy, nhấn vào trường sinh và tình thân. Gợi ý phát triển đan đạo và tương tác với đạo hữu.

Đây là diễn giải thiết kế của Vân Đạo từ giới thiệu tác phẩm, không tuyên bố các cơ chế game là hệ thống chính xác trong từng truyện. Nhân vật, đối thoại, địa danh và ủy thác mới được viết riêng cho game; không sao chép cốt truyện hay chân dung của các tác phẩm.
