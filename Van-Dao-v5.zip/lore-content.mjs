const herbs=[
 ['Thanh Tâm Thảo','Mộc',10,'Bờ linh tuyền, dược tính ôn hòa; thanh tâm an thần.',0],
 ['Bách Niên Huyết Sâm','Mộc',100,'Hấp thu địa khí trăm năm, bổ huyết dưỡng nguyên.',0],
 ['Tử Hầu Hoa','Mộc',100,'Cánh tím như mây, dược dẫn củng cố đạo cơ.',1],
 ['Thiên Linh Quả','Mộc',300,'Quả mọc trên cổ thụ, chứa linh khí tinh thuần.',2],
 ['Địa Hỏa Liên','Hỏa',500,'Sinh trong khe địa hỏa, rễ như tơ vàng.',3],
 ['Băng Tâm Tuyết Liên','Băng',500,'Nở trên tuyết sơn, áp chế đan độc và tâm ma.',4],
 ['Cửu Diệp Linh Chi','Mộc',1000,'Chín phiến lá tích lũy ngàn năm đạo vận.',4],
 ['Ngọc Tủy Kim Chi','Kim',1000,'Thân vàng trong suốt, quý dược ngưng kết Kim Đan.',6],
 ['Dưỡng Hồn Mộc','Mộc',3000,'Linh mộc nuôi dưỡng thần thức và hồn phách.',8],
 ['Lôi Kiếp Thảo','Lôi',3000,'Chịu chín lần lôi kích vẫn không tàn úa.',10],
 ['Ngộ Đạo Trà','Mộc',5000,'Một chén trà thơm, một thoáng minh ngộ đại đạo.',12],
 ['Cửu Chuyển Tiên Liên','Thủy',10000,'Vạn năm mới kết một hạt sen, bảo vật của tiên gia.',16]
].map(([name,element,age,description,realm],i)=>({id:'h'+i,name,element,age,description,realm,type:'Linh dược',price:20+age/5}));
const elixirs=[
 {id:'el0',name:'Tẩy Tủy Đan',realm:0,materials:{h0:3,h1:2},effect:'mind',power:3,toxicity:3,success:.9,lore:'Tẩy đi phàm trần, khai thông kinh mạch.',description:'Tăng 3 tâm cảnh.'},
 {id:'el1',name:'Thanh Linh Tán',realm:0,materials:{h0:4,m0:3},effect:'purify',power:20,toxicity:0,success:.95,lore:'Dược tính thanh mát, trừ tạp chất trong kinh mạch.',description:'Giảm 20 đan độc.'},
 {id:'el2',name:'Bồi Nguyên Đan',realm:1,materials:{h1:3,h2:2},effect:'xpSeconds',power:150,toxicity:5,success:.85,lore:'Củng cố căn cơ, tụ khí dưỡng nguyên.',description:'Nhận tu vi bằng 150 giây tu luyện.'},
 {id:'el3',name:'Hộ Mạch Đan',realm:2,materials:{h2:3,h3:2},effect:'breakthrough',power:.12,toxicity:4,success:.83,lore:'Bảo hộ kinh mạch trong khoảnh khắc phá cảnh.',description:'Thêm 12% tỉ lệ đột phá lần kế tiếp.'},
 {id:'el4',name:'Huyền Nguyên Đan',realm:4,materials:{h4:3,h6:2},effect:'xpSeconds',power:300,toxicity:6,success:.8,lore:'Linh khí hóa dịch, đạo cơ thêm vững.',description:'Nhận tu vi bằng 300 giây tu luyện.'},
 {id:'el5',name:'Băng Tâm Đan',realm:4,materials:{h5:3,h0:4},effect:'purify',power:50,toxicity:0,success:.87,lore:'Một niệm băng tâm, vạn tà bất xâm.',description:'Giảm 50 đan độc.'},
 {id:'el6',name:'Kết Kim Đan',realm:7,materials:{h7:3,h6:3,h4:2},effect:'breakthrough',power:.2,toxicity:8,success:.72,lore:'Đan điền ngưng tụ một hạt kim quang.',description:'Thêm 20% tỉ lệ đột phá lần kế tiếp.'},
 {id:'el7',name:'Ngộ Đạo Đan',realm:12,materials:{h10:3,h8:3,h9:2},effect:'mind',power:15,toxicity:8,success:.7,lore:'Đạo vận lưu chuyển, thần thức như gương sáng.',description:'Tăng 15 tâm cảnh.'},
 {id:'el8',name:'Dưỡng Hồn Đan',realm:8,materials:{h8:2,h6:3},effect:'mind',power:8,toxicity:5,success:.78,lore:'Mộc hương ôn dưỡng hồn phách, đạo tâm càng thêm kiên định.',description:'Tăng 8 tâm cảnh.'},
 {id:'el9',name:'Cửu Chuyển Quy Nguyên Đan',realm:16,materials:{h11:2,h10:3,h9:3},effect:'xpSeconds',power:900,toxicity:10,success:.65,lore:'Vạn niên tiên liên quy tụ chín vòng đan văn, linh cơ cuồn cuộn.',description:'Nhận tu vi bằng 900 giây tu luyện.'}
];
const qualities=[{id:'lower',name:'Hạ phẩm',multiplier:1,color:'common'},{id:'middle',name:'Trung phẩm',multiplier:1.5,color:'uncommon'},{id:'upper',name:'Thượng phẩm',multiplier:2.2,color:'rare'},{id:'perfect',name:'Cực phẩm',multiplier:3,color:'legendary'}];
const treasures=[
 {id:'relic0',name:'Thanh Hư Cổ Kính',symbol:'鏡',grade:'Huyền',stat:'xp',bonus:.18,description:'Tấm cổ kính phủ đồng xanh, phản chiếu đạo vận giữa mây.',effect:'Tu luyện +18%',source:'Kỳ ngộ và lịch luyện'},
 {id:'relic1',name:'Sơn Hà Ấn',symbol:'印',grade:'Huyền',stat:'defense',bonus:.25,description:'Một ấn nhỏ nặng tựa sơn hà, trấn giữ mệnh môn.',effect:'Phòng ngự +25%',source:'Boss và Vấn Thiên Tháp'},
 {id:'relic2',name:'Huyết Linh Châu',symbol:'珠',grade:'Huyền',stat:'hp',bonus:.25,description:'Linh châu sắc hồng, sinh cơ cuồn cuộn không dứt.',effect:'Sinh lực tối đa +25%',source:'Boss và lịch luyện'},
 {id:'relic3',name:'Cửu Tiêu Kiếm Hoàn',symbol:'劍',grade:'Địa',stat:'attack',bonus:.2,description:'Kiếm hoàn phát tiếng ngân khi gặp yêu khí.',effect:'Công kích +20%',source:'Boss và Vấn Thiên Tháp'},
 {id:'relic4',name:'Tạo Hóa Ngọc Điệp',symbol:'碟',grade:'Địa',stat:'alchemy',bonus:.06,description:'Ngọc điệp chép những nét đan văn cổ xưa.',effect:'Thành đan +6%',source:'Kỳ ngộ và lịch luyện'},
 {id:'relic5',name:'Thất Tinh Dược Đỉnh',symbol:'鼎',grade:'Địa',stat:'harvest',bonus:.35,description:'Bảy ngôi sao sáng trên miệng đỉnh, dưỡng dược tăng linh.',effect:'Thu hoạch linh dược +35%',source:'Boss và kỳ ngộ'},
 {id:'relic6',name:'Bồ Đề Tâm Liên',symbol:'蓮',grade:'Thiên',stat:'breakthrough',bonus:.05,description:'Một đóa tâm liên giúp đạo tâm vững trước lôi kiếp.',effect:'Đột phá +5%',source:'Sưu tầm 6 dị bảo đầu tiên'},
 {id:'relic7',name:'Hư Thiên Bảo Đỉnh',symbol:'寶',grade:'Thiên',stat:'xp',bonus:.4,description:'Cổ đỉnh hút linh khí từ hư không, có thể luyện hóa tàn bảo.',effect:'Tu luyện +40%',source:'Vượt tầng tháp 10'}
];
export function enrich(data){
 const basePills=data.items.filter(i=>i.type==='Đan dược').map(i=>({...i,quality:'lower',baseId:i.id,multiplier:1,toxicity:2}));
 const added=elixirs.map(e=>({...e,type:'Đan dược',price:100+e.realm*50,quality:'lower',baseId:e.id,multiplier:1}));
 const allPills=[...basePills,...added];
 const upgraded=allPills.flatMap(p=>qualities.slice(1).map(q=>({...p,id:p.id+'-'+q.id,name:p.name+' · '+q.name,baseId:p.id,quality:q.id,multiplier:q.multiplier,description:p.description+' Hiệu lực ×'+q.multiplier+'.',price:Math.round(p.price*q.multiplier*1.5)})));
 const items=[...data.items.filter(i=>i.type!=='Đan dược'),...herbs,...allPills,...upgraded];
 const newCrops=herbs.map((h,i)=>({id:'crop-'+h.id,name:h.name,symbol:['草','參','花','果','蓮','蓮','芝','芝','木','雷','茶','蓮'][i],cost:12+i*12,duration:55+i*20,item:h.id,yield:3,realm:h.realm,description:h.age+' năm · '+h.element+' hệ'}));
 return {...data,version:3,items,recipes:[...data.recipes,...elixirs],crops:[...data.crops,...newCrops],herbs,qualities,treasures};
}
