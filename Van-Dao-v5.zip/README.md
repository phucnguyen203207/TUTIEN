# Vân Đạo 5.0 — Gia tộc & linh căn

Game idle tu tiên chơi đơn, lưu trên thiết bị. Không cần tài khoản hoặc backend.

## Chơi ngay

Mở **Choi-Van-Dao.html** bằng trình duyệt. Dữ liệu, hình vẽ, CSS và mã game đã gộp trong một file. Font Google là tùy chọn; mất mạng dùng font dự phòng. Xuất bản lưu trong Cài đặt để sao lưu hoặc chuyển thiết bị.

Nếu có tiến trình 1.0, mở file mới tại cùng vị trí bằng cùng trình duyệt; dữ liệu được nâng cấp lên phiên bản 2. Có thể nhập file lưu 1.0. Trình duyệt có thể quản lý localStorage của file HTML khác nhau, vì vậy xuất/nhập JSON là cách chuyển tiến trình chắc chắn nhất.

## Cơ chế mới

- **Động phủ**: 3 ô linh điền ban đầu, 4 giống cây. Cây tiếp tục lớn khi đóng game. Nâng dược viên để mở tới 9 ô, thu hoạch hàng loạt.
- **Công trình**: Tụ Linh Trận tăng tu luyện; Dược Viên tăng sản lượng/số ô; Đan Lô tăng tỉ lệ thành đan.
- **Luyện khí**: 6 pháp bảo, 3 vị trí trang bị, hai phẩm cấp, cường hóa tới +10. Tác động thật đến tu luyện và chiến đấu.
- **Tông môn**: Thanh Vân Tông, Vạn Kiếm Sơn, Dược Vương Cốc, mỗi phái có gia hộ riêng. Nhiệm vụ hộ sơn và hiến linh thảo cho cống hiến. Chức vị theo tổng cống hiến; Tàng bảo các đổi đan/Tiên ngọc.
- **Linh hồ Tiểu Bạch**: kết duyên, nuôi tới cấp 10, tăng tu luyện và trợ chiến mỗi 2 lượt.
- **Vấn Thiên Tháp**: 30 tầng khó tăng dần. Thưởng vượt tầng chỉ nhận một lần. Mỗi 5 tầng có hộ pháp và điểm ngộ đạo.
- **Thiên phú**: 6 nhánh, mỗi nhánh 5 cấp, tăng tu luyện, công, sinh lực, đột phá, chí mạng/linh thạch hoặc thu hoạch. Giữ lại khi chuyển sinh.
- **Thành tựu**: 12 mục tiêu thưởng linh thạch và ngộ đạo, nhận từng mục hoặc tất cả, không nhận lặp.
- **Kỳ ngộ**: 3 sự kiện có lựa chọn sau lịch luyện, thưởng vật liệu, tâm cảnh, tu vi hoặc Tiên ngọc.
- **Điểm danh**: quà theo ngày và chuỗi liên tiếp. **Nhập định**: dùng 1 Tiên ngọc tăng tốc 50% trong 60 giây, tính đúng thời gian có hiệu lực.
- **Giao diện**: phong cảnh sơn thủy SVG, linh khí bay, minh họa linh hồ/pháp bảo/tháp, bảng hoạt động nhanh, chủ đề giấy ngà và đêm ngọc bích, menu điện thoại.

Giữ lại 20 bậc cảnh giới, 7 linh căn, 10 công pháp, 10 thần thông, 35 vật phẩm, 8 đan phương, 5 khu vực, 15 yêu thú và 5 boss, 15 nhiệm vụ chính tuyến và nhiệm vụ ngày, chuyển sinh, xuất/nhập file, sao lưu trước khi ghi, offline tu vi tối đa 8 giờ.

## Phát triển

Chạy lần lượt:

```powershell
node generate-data.mjs
node build-game.mjs
node test.mjs
node test-state.mjs
node bundle-play.mjs
node server.mjs
```

Mở http://localhost:4173.

- src/core.js: vòng lặp, chiến đấu và cơ chế ban đầu.
- src/expansion.js: cơ chế, giao diện và nâng bản lưu 2.0.
- build-game.mjs: gộp thành dist/app.js (không sửa trực tiếp file được sinh).
- dist/formulas.js: công thức tập trung, gồm trang bị, tông môn, thiên phú, linh thú, nhập định.
- generate-data.mjs và expansion-content.mjs: sinh dist/data.json.
- dist/style.css và dist/expansion.css: giao diện/chủ đề.
- bundle-play.mjs: sinh HTML độc lập, kiểm tra cú pháp trước khi ghi.

## Kiểm tra

Kiểm thử công thức, giới hạn offline/thời gian nhập định, tăng trưởng tháp, lưu/khôi phục bản hỏng, migration 1.0, hồi chiêu, chống nhận thưởng lặp, trồng/thu hoạch, mở đất, rèn/cường hóa và chỉ số trang bị, gia hộ tông môn, kỳ ngộ, thành tựu, thưởng tháp và render các trang mới. Kiểm tra trình duyệt ở kích thước máy tính và điện thoại.

## Phạm vi

Một ô lưu đang hoạt động, file xuất dùng làm bản dự phòng. Offline có tu vi, hồi phục, cây trồng và bộ đếm lịch luyện; không đánh quái khi đóng trang. Thiên kiếp còn dùng phép thử đột phá. Thọ nguyên là thông tin hiển thị. Chưa có tử vong vì tuổi thọ, PvP, tài khoản/cloud, nhiệm vụ tuần, khảm ngọc, trang phục, PWA, nhạc nền. Tốc độ và thần thức chưa tham gia chiến đấu. Không đổi tông môn trong cùng một kiếp. Chuyển sinh giữ đạo hiệu, thiên phú, ngộ đạo và thành tựu đã nhận; các tiến trình khác bắt đầu lại. Cân bằng dài hạn cần thêm chơi thử.

## Bản 3.0 — Linh dược dị bảo

- Tu vi luôn tăng tự động. Tự vận chu thiên bật sẵn, thêm 40% tốc độ cả online và offline. Nút thổ nạp vẫn cho thêm tu vi khi chơi chủ động.
- Tùy chọn tự thử đột phá mỗi 20 giây khi đủ tu vi và đang mở game; có rủi ro thất bại mất 15% tu vi yêu cầu. Tùy chọn tự thu cây đã chín, không tự mua hạt giống. Hai tùy chọn này mặc định tắt.
- 12 linh dược từ 10 năm đến vạn năm, có hệ, dược tính, cảnh giới và đan phương liên quan. Trồng ở linh điền, tìm khi lịch luyện/đánh boss hoặc mua từ Bách thảo lục. Niên đại là bậc dược liệu định sẵn, không phải số năm thực phải chờ.
- Tổng cộng 18 đan phương, 4 phẩm chất Hạ/Trung/Thượng/Cực với hiệu lực x1/x1.5/x2.2/x3. Đan sư nhận kinh nghiệm cả khi thất bại, tối đa 9 phẩm. Đan lô và tu vi đan sư tăng cơ hội thành đan/phẩm chất cao.
- Đan độc tối đa 100, giảm tối đa 20% tốc độ tu luyện. Tự giảm 1 mỗi 90 giây; Thanh Linh Tán và Băng Tâm Đan thanh lọc. Đan phẩm cao có ít đan độc hơn. Đan hỗ trợ đột phá không cộng dồn; giữ hiệu lực cao nhất, tổng tỉ lệ tối đa 98%.
- 8 dị bảo với hiệu ứng riêng: Thanh Hư Cổ Kính, Sơn Hà Ấn, Huyết Linh Châu, Cửu Tiêu Kiếm Hoàn, Tạo Hóa Ngọc Điệp, Thất Tinh Dược Đỉnh, Bồ Đề Tâm Liên, Hư Thiên Bảo Đỉnh.
- Luyện hóa đồng thời 2 dị bảo. Tàn bảo trùng cho 2 Bảo tinh; dùng Bảo tinh và linh thạch tăng tầng tối đa 5. Giữ dị bảo, kinh nghiệm đan sư và cấu hình tự động khi chuyển sinh.
- Chuyến lịch luyện đầu tiên sau nâng cấp bảo đảm nhận Thanh Hư Cổ Kính; boss đầu tiên cho Sơn Hà Ấn nếu chưa có. Sau đó có cơ hội rơi thêm dị bảo. Gom 6 dị bảo đầu để thức tỉnh Bồ Đề Tâm Liên; vượt tháp tầng 10 nhận Hư Thiên Bảo Đỉnh.
- Túi đồ mở lên 80 ô, có lọc linh dược, tổng cộng 111 định nghĩa vật phẩm (gồm biến thể đan phẩm).
- Nâng save 1.0/2.0 lên schema 3 tự động, giữ đạo hiệu và tiến trình. Giữ nguyên khóa lưu để bản HTML cùng vị trí đọc được dữ liệu trước.

Mã mới ở src/lore.js, dữ liệu ở lore-content.mjs, giao diện ở dist/lore.css. Các bước build/chơi vẫn như trên. Phần mô tả bản 2.0 phía trên là lịch sử chức năng, số lượng vật phẩm/đan phương hiện tại theo phần 3.0 này.

## Bản 4.0 — Tiên duyên nhân gian

Bản cục bộ, không tải mã nguồn hay tiến trình lên Sites.

- **6 nhân vật được vẽ riêng**: Diệp Thanh La (dược sư), Lục Trường Phong (kiếm tu), Tề Vân Tử (đan sư), Hồng Liên (phù sư), Mặc Cửu (du thương), Tô Nguyệt Bạch (trận sư). Mỗi người có giới thiệu, 3 câu đối thoại luân phiên, quà ưa thích và 3 ủy thác, tổng 18 ủy thác NPC.
- **Quan hệ**: trò chuyện lần đầu mỗi ngày +4 hảo cảm; tặng tối đa 3 lễ/người/ngày, mỗi lễ +6; ủy thác +10. Đạt 20 để mời 1 người đồng hành và nhận gia hộ riêng. Mốc 50 tâm giao, 80 tri kỷ, tối đa 100.
- **Chân dung người chơi**: chọn trong 6 tranh, hiển thị ở động phủ và thẻ nhân vật. Ảnh được nhúng trong HTML độc lập; không cần mạng để tải.
- **8 phù lục**: tự chế từ Chu sa, Linh phù chỉ và linh vật, hoặc mua. Phù công/phòng gia trì trong 3 trận, hết trận thì giảm số lượt, phù cùng loại giữ hiệu lực cao nhất. Không dùng phù khi đang giao chiến. Phù tụ linh/thần hành cho tu vi tức thời; phù tịnh linh giảm đan độc.
- **3 đại trận**: dưỡng linh, kiếm trận, trấn sơn, tối đa 5 tầng. Chỉ hoạt động một trận cùng lúc. Tác động trực tiếp vào công thức chỉ số, tách với công trình Tụ Linh Trận cũ.
- **4 bí cảnh**: Trúc Lâm Cổ Cảnh, Xích Hà Địa Cung, Vân Hải Tinh Điện, Thái Hư Tiên Tàng. Giới hạn chung 3 lượt vào/ngày. Hai chặng chọn tìm kiếm thận trọng hoặc phá cấm chế 70% thưởng lớn, thất bại mất 12% sinh lực tối đa nhưng không chết. Chặng cuối giao chiến tự động với thủ vệ. Thắng bảo đảm dị bảo nhóm tiên tàng, hoặc Bảo tinh nếu trùng, kèm 2 Tiên ngọc và vật liệu. Thua có thể dưỡng thương rồi thử lại trong cùng chuyến. Rời bí cảnh vẫn mất lượt đã dùng.
- **Vạn Bảo Các**: 14 mặt hàng vật liệu/phù/dị bảo, mỗi mặt hàng tối đa 3 lần mua/6 giờ, hàng quý yêu cầu cảnh giới. Mặc Cửu đồng hành giảm 10% giá. Đây là cửa hàng giá cố định, không phải đấu giá trực tuyến.
- **Nội dung tổng**: 177 định nghĩa vật phẩm (kể cả các phẩm chất linh đan), 26 đan phương, 20 linh dược, 18 pháp bảo, 14 dị bảo, 8 phù lục, 3 đại trận, 6 NPC, 4 bí cảnh. Nội dung trước vẫn giữ lại.
- **Save schema 4**: nâng tự động từ 1/2/3, giữ tiến trình tương ứng. Chuyển sinh giữ thêm quan hệ, đạo hữu đồng hành và chân dung; các hệ thống theo kiếp như trận pháp/bí cảnh bắt đầu lại.

Mã ở src/world.js, dữ liệu ở world-content.mjs, giao diện ở dist/world.css. Atlas gốc PNG và bản JPEG tối ưu ở dist/assets/. HTML độc lập dùng JPEG khoảng 570 KB. Chi tiết prompt và nguồn tham khảo ở ART-NOTES.md. Nhân vật và đối thoại là nguyên bản cho Vân Đạo.

Kiểm thử bổ sung: migration 3.0, giới hạn trò chuyện/quà tặng, gia hộ đồng hành, ủy thác không nhận trùng, hạn mức cửa hàng, chế và dùng phù, số trận gia trì, hiệu quả trận pháp, toàn bộ chuỗi bí cảnh-thủ vệ-thưởng và giới hạn lượt vào. Các phiên bản trước trong README là lịch sử; số lượng hiện tại theo phần 4.0 này.

## Bản 5.0 — Gia tộc & linh căn

- **8 xuất thân**: con nhà dân thường, tán tu phiêu bạt và 6 gia tộc (Lâm gia dược tộc, Lục gia kiếm tu, Mạc gia luyện khí, Tô gia trận đạo, Vân gia thương tộc, cổ tộc sa sút).
- Chọn ngay khi tạo nhân vật. Mỗi xuất thân có quà khởi đầu, lợi thế và hạn chế riêng. Gia tộc độc lập với tông môn. Một lần chọn trong mỗi kiếp, chọn lại sau chuyển sinh.
- **Dân thường**: không trợ cấp, được +3 điểm phần trăm tỉ lệ đột phá. **Tán tu**: không trợ cấp, +10% linh thạch chiến đấu nhưng giá Vạn Bảo Các cao hơn 10%.
- **Gia tộc**: nhận linh thạch/vật liệu mỗi ngày, không nhận lặp. Cống hiến tài nguyên một lần/ngày cho công huân, hoàn toàn tự nguyện, bỏ qua không bị phạt. 60/120/180 công huân mở hệ số trợ cấp x1.25/x1.5/x1.75. Vật phẩm làm tròn xuống. Trợ cấp không cộng dồn các ngày không nhận.
- Lâm gia hợp linh điền/đan đạo nhưng giảm công; Lục gia mạnh kiếm nhưng kém luyện đan; Mạc gia tăng phòng ngự nhưng tu luyện chậm; Tô gia tăng hiệu lực đại trận nhưng ít sinh lực; Vân gia nhiều vốn và giá tốt nhưng yếu công; cổ tộc có cổ pháp tu luyện/đột phá nhưng ít thọ thể và trợ cấp.
- **30 linh căn**: 5 cơ bản, 5 biến dị, 5 thiên linh, 7 đa hệ, 8 đặc thù. Có thể chọn bất kỳ từ màn hình tạo nhân vật; nút ngẫu nhiên dùng trọng số, các loại hiếm có xác suất thấp hơn. Bảng Linh căn hiển thị tốc độ, hệ chiến đấu, ưu điểm, hạn chế và hệ công pháp cộng hưởng.
- Cộng hưởng tăng thêm 25% phần thưởng công pháp phù hợp; đa hệ mở rộng danh sách phù hợp, không nhân nhiều lần một công pháp. Hệ chiến đấu của linh căn riêng với hệ thần thông: chiêu thức dùng hệ của chiêu khi thi triển.
- Ưu/nhược điểm tác động thật tới công, thủ, sinh lực, linh lực, chí mạng, tỉ lệ đột phá, luyện đan, sản lượng, đan độc và chuyển sinh. Điểm phần trăm dùng cho chí mạng/thành đan/đột phá, không phải nhân với tỉ lệ đang có. Chỉ số và sản lượng có làm tròn.
- Ví dụ: Lôi tăng công/chí mạng nhưng giảm đột phá và luyện đan; Thiên Hỏa mạnh đan đạo nhưng giảm sinh lực; Ngũ Hành tương hợp 5 hệ và dễ đột phá nhưng tu luyện cơ bản chậm; Vô linh căn cho võ thể mạnh nhưng tu luyện x0.70, không có cộng hưởng; Độc Mộc nhận nửa đan độc; Hỗn Nguyên x1.85 tu luyện nhưng khó phá cảnh và nhận thêm đan độc; Luân Hồi thêm 15% hệ số tu luyện trên mỗi lần chuyển sinh bên cạnh 30% chuẩn.
- **Save schema 5**: giữ tiến trình và tên linh căn cũ khi nâng từ 1/2/3/4. Có một lần chọn xuất thân và một lần xác định linh căn miễn phí trong kiếp hiện tại, không cần xóa save. Mở tab Xuất thân và Linh căn để chọn. Chuyển sinh bắt đầu xuất thân mới, có thể chọn lại; những phần thưởng vĩnh viễn cũ vẫn theo quy tắc của các bản trước.

Mã ở src/ancestry.js, nội dung ở ancestry-content.mjs, giao diện ở dist/ancestry.css. Công thức vẫn tập trung tại dist/formulas.js. Kiểm thử thêm: mọi linh căn cho chỉ số hữu hạn, tác dụng hai mặt, cộng hưởng đa hệ, kháng đan độc, chuyển sinh, quà đầu không trùng, trợ cấp/cống hiến một lần/ngày, công huân, dân thường không trợ cấp, gia tộc tác động giá/trận pháp, migration giữ tiến trình.

Máy chủ xem thử hỗ trợ cổng riêng: node server.mjs 4185. Điều này giúp thử nhân vật mới mà không thay đổi ô lưu trên cổng đang chơi. File HTML độc lập vẫn là cách chơi chính.
