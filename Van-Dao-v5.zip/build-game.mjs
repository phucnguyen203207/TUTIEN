import {readFileSync,writeFileSync} from 'node:fs';
import vm from 'node:vm';
const read=p=>readFileSync(new URL(p,import.meta.url),'utf8');
const app=read('./src/core.js').replace('// EXPANSION_BOOTSTRAP',read('./src/expansion.js')+'\n'+read('./src/lore.js')+'\n'+read('./src/world.js')+'\n'+read('./src/ancestry.js'));
new vm.Script(app.replace("import * as F from './formulas.js';",'').replace(/^const D=.*$/m,'const D={};'));
writeFileSync(new URL('./dist/app.js',import.meta.url),app);
console.log('Built Vân Đạo 5.0');
